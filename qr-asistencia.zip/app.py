from flask import Flask, redirect
import random

app = Flask(__name__)

# Lista de tus formularios (pueden ser duplicados del mismo)
formularios = [
    "https://forms.gle/FORM1",
    "https://forms.gle/FORM2",
    "https://forms.gle/FORM3"
]

@app.route("/")
def redirigir():
    return redirect(random.choice(formularios))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
